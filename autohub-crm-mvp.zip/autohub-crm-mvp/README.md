# AutoHub CRM MVP

MVP CRM для холдинга автосалонов.

## Возможности
- Авторизация с ролями.
- Клиенты и лиды.
- Работа колл-центра.
- Статусы: новый, в работе, недозвон, отказ, на визит, визит состоялся, продажа.
- Запись на визит с выбором автосалона и отдела.
- Автоматические уведомления внутри CRM.
- Кредитные заявки.
- Dashboard и базовая аналитика.
- PostgreSQL через Prisma.
- React + TypeScript frontend.
- Express + TypeScript backend.

## Запуск
1. Установить Node.js 20+ и PostgreSQL.
2. `cd server && npm install`
3. Создать `.env` по примеру `.env.example`.
4. `npx prisma migrate dev --name init`
5. `npm run seed`
6. `npm run dev`
7. В отдельном терминале: `cd client && npm install && npm run dev`

Frontend: http://localhost:5173
API: http://localhost:4000

Тестовые пользователи:
- admin@autohub.local / admin123
- operator@autohub.local / operator123
- manager@autohub.local / manager123
- credit@autohub.local / credit123

Это MVP: перед production необходимо добавить полноценный RBAC, audit log, защищённую загрузку документов, rate limiting, HTTPS, резервное копирование, CSRF/CORS policy и интеграции телефонии/Telegram.
